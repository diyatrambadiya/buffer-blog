// next.config.js
module.exports = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  images: {
    domains: ["nextui.org"],
  },
};
